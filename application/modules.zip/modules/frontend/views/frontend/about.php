<!DOCTYPE html>
<html lang="en">

<head>
    <?php require('inc_header.php'); ?>
</head>

<body>
    <?php require('inc_menu.php'); ?>
    <div class="container-fluid">
        <div class="row pad-banner">
            <div class="col-12 nopan banner wow fadeInDown">
                <div class="text_banner">
                    <h2>About us</h2>
                    <p><a href="index.php">Home</a> l About us</p>
                </div>
                <img src="<?php echo base_frontend('images/banner/about.jpg');?>" class="img-fluid" style="width: 100%;">
            </div>
        </div>
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-12 wow fadeInDown">
                        <div class="row text_about">
                            <div class="col-12 col-md-12 col-lg-6 col-xl-6">
                                <div class="topic_about">
                                    <h4>Lorem Ipsum is simply dummy</h4>
                                </div>
                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal </p>
                                <p>distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum </p>
                                <p>as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                            </div>
                            <div class="col-12 col-md-12 col-lg-6 col-xl-6 pad_img_about">
                                <img src="<?php echo base_frontend('images/img_about_1.jpg');?>" class="img-fluid">
                            </div>
                            
                            
                            <div class="col-12 col-md-12 col-lg-6 col-xl-6 p_md_img_about">
                                <img src="<?php echo base_frontend('images/img_about_2.jpg');?>" class="img-fluid">
                            </div>
                            <div class="col-12 col-md-12 col-lg-6 col-xl-6">
                                
                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal </p>
                                <p>distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum </p>
                                <p>as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php require('inc_footer.php'); ?>
    </div>
</body>

</html>