<!DOCTYPE html>
<html lang="en">

<head>
    <?php require('inc_header.php'); ?>
</head>

<style>
    
</style>
<body>
    <?php require('inc_menu.php'); ?>
        
    <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-12 pad_account_1">
                    <div class="boxtext_help">
                        <h2>My Account</h2>
                    </div>
                    <div class="row pad_account">
                        <div class="col-12 col-md-12 col-lg-3">
                            <?php require('inc_account.php'); ?>
                        </div>
                        <div class="col-12 col-md-12 col-lg-9 bg_payment">
                            <div class="text-myaccount">
                                <h5>My Account</h5>
                            </div>
                            <div class="id-number">
                                <p>Member Code : <?php echo $this->session->userdata('member_id');?></p>
                            </div>
                            <div class="row padding-user-1">
                                <div class="col-6 col-md-4 col-lg-3">
                                    <div class="personal-text-1">Name : </div>
                                    <div class="personal-text-1">Last Names : </div>
                                    <div class="personal-text-1">Phone : </div>
                                    <div class="personal-text-1">E-mail :</div>
                                    <hr>
                                </div>
                                <div class="col-6 col-md-6 col-lg-7">
                                    <div class="personal-text"><?php if(!empty($memberCtrl)) echo $memberCtrl->member_first_name;?></div>
                                    <div class="personal-text"><?php if(!empty($memberCtrl)) echo $memberCtrl->member_last_name;?></div>
                                    <div class="personal-text"><?php if(!empty($memberCtrl)) echo $memberCtrl->member_phone;?></div>
                                    <div class="personal-text"><?php if(!empty($memberCtrl)) echo $memberCtrl->member_email;?></div>
                                    <hr>
                                </div>
                                <div class="col-12 col-md-2 col-lg-2">
                                    <div class="modify">
                                        <a href="<?php echo site_frontend('member2.php');?>">Edit</a>
                                    </div>
                                </div>
                            </div>
                            <div class="text-myaccount-1">
                                <h5>Delivery Information</h5>
                            </div>

                            <div class="row padding-user">
                                <div class="col-10 col-md-10 col-lg-10">

                                </div>
                                <div class="col-2 col-md-2 col-lg-2">
                                    <div class="modify">
                                        <a href="<?php echo site_frontend('member3.php');?>">Edit</a>
                                    </div>
                                </div>
<?php
if(!empty($shipping)) {
    foreach($shipping as $s) {
?>
                            
                                <div class="col-6 col-md-5 col-lg-4">
                                    <div class="personal-text-1">Address : </div>
                                    <div class="personal-text-1">District : </div>
                                    <div class="personal-text-1">Township : </div>
                                    <div class="personal-text-1">Region/State : </div>
                                    <div class="personal-text-1">Postal Code : </div>
                                    <hr>
                                </div>
                                <div class="col-6 col-md-7 col-lg-8">
                                    <div class="personal-text"><?php echo $s->member_shipping_address_address;?></div>
                                    <div class="personal-text"><?php echo $s->member_shipping_address_sub_district;?></div>
                                    <div class="personal-text"><?php echo $s->shipping_township;?></div>
                                    <div class="personal-text"><?php echo $s->shipping_location;?></div>
                                    <div class="personal-text"><?php echo $s->member_shipping_address_postal_code;?></div>
                                    <hr>
                                </div>
<?php
    }
}
?>
                            </div>
                            
                            <div class="text-myaccount-1">
                                <h5>Tax invoice</h5>
                            </div>
                            <div class="row padding-user">
                                <div class="col-6 col-md-4 col-lg-3">
                                    <div class="personal-text-1">Name : </div>
                                    <div class="personal-text-1">Tax number : </div>
                                    <div class="personal-text-1">Branch office : </div>
                                    <div class="personal-text-1">Phone : </div>
                                    <div class="personal-text-1">Address : </div>
                                    <hr>
                                </div>
                                <div class="col-6 col-md-6 col-lg-7">
                                    <div class="personal-text"><?php if(!empty($billingCtrl)) echo $billingCtrl->member_billing_name_surname;?></div>
                                    <div class="personal-text"><?php if(!empty($billingCtrl)) echo $billingCtrl->member_billing_tax_number;?></div>
                                    <div class="personal-text"><?php if(!empty($billingCtrl)) echo $billingCtrl->member_billing_branch_office;?></div>
                                    <div class="personal-text"><?php if(!empty($billingCtrl)) echo $billingCtrl->member_billing_phone;?></div>
                                    <div class="personal-text"><?php if(!empty($billingCtrl)) echo $billingCtrl->member_billing_address;?></div>
                                    <hr>
                                </div>
                                <div class="col-2 col-md-2 col-lg-2">
                                    <div class="modify">
                                        <a href="<?php echo site_frontend('member3.php');?>">Edit</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php require('inc_footer.php'); ?>
        <script>
            $('.sidemenumem li:nth-child(1) ').addClass('active');
        </script>

    </div>

</body>

</html>